# Local Setup
- Clone the project


# Local Development Run
- `python app.py` It will start the flask app in `development`. Suited for local development. 

# Replit run
- Click on `main.py` and click button run
- The web app will be availabe at https://appName.userName.repl.co
- Format https://<replname>.<username>.repl.co

# Folder Structure

- `database.db` is the sqlite DB. It can be anywhere on the machine. Adjust the path in `__init__.py`. This app ships with one required for testing.
- `/` is where our application code is
- `static` - default `static` files folder. It serves at '/static' path.
- `templates` - Default flask templates folder


```
Flashcard/
├── __init__.py
├── api.py
├── project.sqlite3
├── readme.md
├── views.py
├── models.py
├── static/
│   └── img
│      └──fclogo.png
├── templates/
│   ├── register.html
│   ├── dashboard.html
│   ├── review.html
│   ├── login.html
└── 
```